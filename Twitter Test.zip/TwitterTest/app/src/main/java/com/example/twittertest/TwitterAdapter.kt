package com.example.twittertest

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.SimpleExoPlayer
import com.google.android.exoplayer2.ui.PlayerView
import com.google.android.exoplayer2.upstream.cache.CacheDataSource
import com.google.android.exoplayer2.util.MimeTypes


class TwitterAdapter(private val listUrls: List<String>) : RecyclerView.Adapter<TwitterViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TwitterViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(
            R.layout.twitter_item_video,
            parent,
            false
        )
        return TwitterViewHolder(view)
    }

    override fun onBindViewHolder(holder: TwitterViewHolder, position: Int) {
        val streamUri = MediaItem.Builder().setUri(listUrls[position])
        val player = SimpleExoPlayer.Builder(holder.itemView.context).build()
        holder.player.player = player
        player.setMediaItem(streamUri.setMimeType(MimeTypes.APPLICATION_MP4)
                ProgressiveMediaSource.Factory(
                CacheDataSource.Factory().setCache(cache)
                    .setUpstreamDataSourceFactory(defaultDataSourceFactory())
                    .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
                ).createMediaSource(streamUri.build()))
        player.prepare()
    }

    override fun getItemCount(): Int = listUrls.size
}

class TwitterViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    val player = itemView.findViewById<PlayerView>(R.id.player)
}