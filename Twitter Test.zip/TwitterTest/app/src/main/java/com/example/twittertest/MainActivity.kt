package com.example.twittertest

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val adapter = TwitterAdapter(
            listOf(
                "https://vod-progressive.akamaized.net/exp=1608758534~acl=%2A%2F1298989897.mp4%2A~hmac=3b0090b9aa9eebacf290666e1cc06fd104e950716835b2cab606cda878f00c57/vimeo-prod-skyfire-std-us/01/1138/13/330694222/1298989897.mp4",
                "https://vod-progressive.akamaized.net/exp=1608758534~acl=%2A%2F1298989897.mp4%2A~hmac=3b0090b9aa9eebacf290666e1cc06fd104e950716835b2cab606cda878f00c57/vimeo-prod-skyfire-std-us/01/1138/13/330694222/1298989897.mp4",
                "https://vod-progressive.akamaized.net/exp=1608758534~acl=%2A%2F1298989897.mp4%2A~hmac=3b0090b9aa9eebacf290666e1cc06fd104e950716835b2cab606cda878f00c57/vimeo-prod-skyfire-std-us/01/1138/13/330694222/1298989897.mp4",
                "https://vod-progressive.akamaized.net/exp=1608758534~acl=%2A%2F1298989897.mp4%2A~hmac=3b0090b9aa9eebacf290666e1cc06fd104e950716835b2cab606cda878f00c57/vimeo-prod-skyfire-std-us/01/1138/13/330694222/1298989897.mp4",
                "https://vod-progressive.akamaized.net/exp=1608758534~acl=%2A%2F1298989897.mp4%2A~hmac=3b0090b9aa9eebacf290666e1cc06fd104e950716835b2cab606cda878f00c57/vimeo-prod-skyfire-std-us/01/1138/13/330694222/1298989897.mp4"
            )
        )
        val recycle = findViewById<RecyclerView>(R.id.recycle)
        recycle.layoutManager = LinearLayoutManager(this)
        recycle.adapter = adapter
    }
}